import React from "react";

const AboutUsPage = () => {
   return <div className="bg-white rounded-lg mx-4 p-4">AboutUsPage</div>;
};

export default AboutUsPage;
